/**
 * 
 */
package com.ibm.sre.sample;

/**
 * @author DALENilsson
 *
 */
public class Test1 {

    /**
     * 
     */
    public Test1() {
	// TODO Auto-generated constructor stub
    }

}
