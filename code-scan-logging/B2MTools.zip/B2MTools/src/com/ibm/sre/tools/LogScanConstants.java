/**
 * 
 */
package com.ibm.sre.tools;

/**
 * @author DALE Nilsson
 *
 */
public interface LogScanConstants {
    public static final String SCAN001 = "SCAN001";
    public static final String Message001 = "{} Exception scanning files";
    public static final String SCAN002 = "SCAN002";
    public static final String Message002 = "{} Excecption scanning pom.xml file";
    public static final String SCAN003 = "SCAN003";
    public static final String Message003 = "{} placeholder";

}
