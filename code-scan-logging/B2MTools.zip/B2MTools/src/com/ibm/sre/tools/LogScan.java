package com.ibm.sre.tools;

/**
 * @author Dale Nilsson
 * Utility to scan Java and Node source code for logging messages
 * Pass the source code path for scanning as an arg 
 * output goes to the console and to a file named 'component'.txt
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LogScan implements LogScanConstants {
    private static final Logger logger = LoggerFactory.getLogger(LogScan.class);
    // holds a list of files with complete path
    private static ArrayList<String> scanlist = new ArrayList<String>();
    // file for scan results
    private static PrintWriter scan_output;
    // variable for Node.js vs Java projects
    private static boolean isNode = false;

    // default constructor
    public LogScan() {
    }

    // get all files and store in an ArrayList
    private static void loadFiles(String path) throws Exception {
	File folder = new File(path);
	// check if the path is valid
	if (folder.isDirectory()) {
	    File[] files = folder.listFiles();
	    // load the all file names from all sub folders into an ArrayList
	    for (File file : files) {
		if (file.isFile()) {
		    //System.out.println("File: " + file.getAbsolutePath());
		    if (file.getName().equalsIgnoreCase("package.json")) { 
			isNode = true;
		    } 
		    // load js and java files
		    if (file.getName().endsWith(".js") || file.getName().endsWith(".java")) {  //$NON-NLS-2$
			// filter support files
			if (!file.getName().equalsIgnoreCase("package-info.java") 
				&& !file.getName().equalsIgnoreCase("config.js")) { 
			    scanlist.add(file.getAbsolutePath());
			}
		    }
		    // load subdirectories
		    // exclude subdirectories that do not have logging
		} else if (file.isDirectory() && !file.getName().equalsIgnoreCase(Messages.getString("LogScan.filter1"))&& !file.getName().equalsIgnoreCase(Messages.getString("LogScan.filter2"))) {  //$NON-NLS-2$
		    //System.out.println("Folder load: " + file.getName());
		    loadFiles(file.getAbsolutePath());
		}
	    }
	} else {
	    // handle bad path passed for scanning
	    throw new Exception("bad path for scanning: "+folder); 
	}
    }
    // display function
    // writes to both an output file and the console
    private static void printOutput(String out) {
	if ("LogScan.output2file".equalsIgnoreCase("true")) {
	    scan_output.println(out);
	}
	System.out.println(out);
    }

    // scan the pom.xml for the kplogger
    private static void scanPom(String path) throws Exception {
	try {
	    // set the path for the pom.xml file

	    File pomfile = new File(path+"\\pom.xml");
	    // check the pom for kplogger dependency and display the version
	    
	    // open the pom.xml to read
	    BufferedReader reader = new BufferedReader(new FileReader(pomfile));
	    boolean noKPlogger = true;
	    // read the first line
	    String line = reader.readLine();
	    printOutput("Processing pom.xml.... ");
	    while (line != null) {
		//System.out.println("pom line"+line);
		if (line.contains(Messages.getString("LogScan.logID"))) { 
		    printOutput(Messages.getString("LogScan.10") + line.trim()); 
		    noKPlogger = false;
		    line = null;
		} else {
		// read the next line
		    line = reader.readLine();
		}
	
	    }
	    // print if no kplogger reference found
	    if (noKPlogger) {
		printOutput(Messages.getString("LogScan.11")); 
	    }
	    
	    reader.close();
	} catch (FileNotFoundException e){
	    // handle missing pom
	    logger.error(Messages.getString("LogScan.missingPom"), "SCAN003", e); 
	} catch (Exception e) {
	    // handle bad pom file
	    logger.error(LogScanConstants.Message002, LogScanConstants.SCAN002, e);
	}
    }

    // scan node package file for the kplogger file
    private static void scanJS(String path) throws Exception {
	printOutput("processing package.json.... "); 
	boolean hasKPlogger = false;
	BufferedReader reader = new BufferedReader(new FileReader(path + "\\package.json")); 
	// read the first line
	String line = reader.readLine();
	while (line != null) {
	    if (line.contains(Messages.getString("LogScan.12"))) { 
		printOutput(Messages.getString("LogScan.10") + line.trim());  
		hasKPlogger = true;
	    }
	    // read the next line
	    line = reader.readLine();
	}
	if (!hasKPlogger) {
	    printOutput(Messages.getString("LogScan.14")); 
	}
	reader.close();
    }

    private static void printMessage(int linenum, String line, BufferedReader reader) throws IOException {
	printOutput("  log line: " + linenum + ": " + line.trim());  //$NON-NLS-2$
	// handle messages that have multiple lines
	while (!line.contains(Messages.getString("LogScan.semicolon")) && !isNode) {  
	    // read next line
	    line = reader.readLine();
	    linenum++;
	    printOutput("  " + line.trim()); 
	}
    }

    /**
     * @param args
     *            [0] pass the start path for the scan
     */
    public static void main(String[] args) {
	String logfatal = ".fatal("; 
	String logerror = ".error("; 
	String logwarning = ".warn("; 
	String loginfo = ".info("; 
	String logdebug = ".debug("; 
	String logcatch = "catch"; 
	int sum_logfatal = 0;
	int sum_logerror = 0;
	int sum_logdebug = 0;
	int sum_loginfo = 0;
	int sum_logwarn = 0;
	int sum_catches = 0;

	try {
	    // check for missing arg with scan path
	    if (args.length == 0) {
		throw new Exception(Messages.getString("LogScan.MissingScanArg"));  
	    }
	    String startpath = args[0];
	    // get application name from passed arg
	    String compname = startpath.substring(startpath.lastIndexOf("\\") + 1, startpath.length()); 

	    // setup the output file
	    FileWriter fileWriter = new FileWriter(Messages.getString("LogScan.outputPath") + compname + ".log");   //$NON-NLS-2$
	    scan_output = new PrintWriter(fileWriter);

	    logger.info("Starting scan for {}", compname); 
	    scan_output.println("Starting scan for " + compname); 

	    // get a list of files to scan
	    loadFiles(startpath);

	    // check the kplogger version used the the project
//	    if (isNode) {
//		printOutput("Node project detected "); 
//		scanJS(startpath);
//	    // process Java project
//	    } else {
//		printOutput(Messages.getString("LogScan.javaProject"));  
//		scanPom(startpath);
//	    }

	    // scan all files for logging messages and catches
	    printOutput("\nStart scanning files in: " + startpath); 

	    for (int allfiles = 0; allfiles < scanlist.size(); allfiles++) {
		String scanfile = scanlist.get(allfiles);
		BufferedReader reader = new BufferedReader(new FileReader(scanfile));
		printOutput("Scanning file: "+ scanfile.substring(scanfile.lastIndexOf("\\") + 1, scanfile.length()));  //$NON-NLS-2$

		String line = reader.readLine();
		int linenum = 1;
		boolean noLogs = true;
		//int num_fatal = 0;
		int num_errors = 0;
		int num_warnings = 0;
		int num_info = 0;
		int num_debug = 0;
		int num_catch = 0;
		// process a file, check for end of file
		while (line != null) {
		    // look for log.fatal
		    if (line.contains(logfatal)) {
			//num_fatal++;
			sum_logfatal++;
			noLogs = false;
			// print the message text
			printMessage(linenum, line, reader);
		    }
		    // look for log.error
		    if (line.contains(logerror)) {
			num_errors++;
			sum_logerror++;
			noLogs = false;
			// print the message text
			printMessage(linenum, line, reader);
		    }
		    // look for log.warn
		    if (line.contains(logwarning)) {
			num_warnings++;
			sum_logwarn++;
			noLogs = false;
			// print the message text
			printMessage(linenum, line, reader);
		    }
		    // count the number of log.debug calls 
		    if (line.contains(logdebug)) {
			num_debug++;
			sum_logdebug++;
			noLogs = false;
		    }
		    if (line.contains(loginfo)) {
			num_info++;
			sum_loginfo++;
			noLogs = false;
			// print the message text
			printMessage(linenum, line, reader);
		    }
		    // count and catches found
		    if (line.contains(logcatch)) {
			num_catch++;
			sum_catches++;
			printOutput("  catch line " + linenum + ": " + line.trim());  //$NON-NLS-2$
		    }
		    // search for Java interface
		    if (line.contains("public interface")) { 
			printOutput(Messages.getString("LogScan.interfaceFound"));  
			noLogs = true;
			line = null;
		    } else {
			// read the next line
			line = reader.readLine();
			linenum++;
		    }
		}
		if (noLogs) {
		    printOutput(Messages.getString("LogScan.noLoggingFound"));  
		} else {
		    // optional list of logging by individual file
		    printOutput("  File scan results:"); 
		    printOutput("  log.error = " + num_errors); 
		    printOutput("  log.warning = " + num_warnings); 
		    printOutput("  log.info = " + num_info); 
		    printOutput("  log.debug = " + num_debug); 
		    printOutput("  number of catches = " + num_catch); 
		}
		reader.close();

	    }
	    // print the scanning totals
	    printOutput("\nScanning totals for " + compname); 
	    printOutput("total files scanned: " + scanlist.size()); 
	    printOutput("total log.fatal: " + sum_logfatal); 
	    printOutput("total log.error: " + sum_logerror); 
	    printOutput("total log.warn: " + sum_logwarn); 
	    printOutput("total log.info: " + sum_loginfo); 
	    printOutput("total log.debug: " + sum_logdebug); 
	    printOutput("total catches: " + sum_catches); 

	    fileWriter.close();

	} catch (Exception e) {
	    logger.error(LogScanConstants.Message001, LogScanConstants.SCAN001, e);
	}
    }

}
